from pathlib import Path
import pandas as pd
import pickle
import xlwings as xw
IDX = pd.IndexSlice
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

eev_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/energiebilanzen/pickles/eev_df.p")
res_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/energiebilanzen/pickles/renewables_df.p")
nea_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/nea/pickles/nea_df.p")
out = Path("C:/Users/WGO/Desktop/statsview_ipynb/files/data.xlsx")
