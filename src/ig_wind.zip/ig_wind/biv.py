
import sys
from settings import provinces_names
from pathlib import Path
import pandas as pd
import pickle
import xlwings as xw

# from src.gui.components.assets.AEA_colors import provinces_color_table_rgb

IDX = pd.IndexSlice
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

eev_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/energiebilanzen/pickles/eev_df.p")
res_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/energiebilanzen/pickles/renewables_df.p")
nea_file = Path(
    "C:/Users/WGO/Desktop/statsview_ipynb/files/nea/pickles/nea_df.p")
out = Path("C:/Users/WGO/Desktop/statsview_ipynb/files/data.xlsx")


# ///////////////////////////////////////////////////////////////////// DATA
_field = "Energetischer Endverbrauch"

_energy_sources = ["Gesamtenergiebilanz"]
_years = list(range(2000, 2019, 1))
dfs = []

for province in _provinces:
    eev_data = eev_df.loc[
        IDX[_field, "Gesamt", "Gesamt", "Gesamt",
            "Gesamt"], IDX[province, _energy_sources, _years]
    ].round(0)
    name = "-".join([x for x in eev_data.name if x != "Gesamt"])
    eev_data.name = province
    eev_data = eev_data.droplevel([0, 1], axis=0)
    dfs.append(eev_data)

df_tj = pd.concat(dfs, axis=1)
df_gwh = (df_tj * c["tj_2_gwh"]).round(0)
df_twh = (df_tj * c["tj_2_twh"]).round(0)
